#!/bin/bash
set -eu

mpiexec -n 4 ./hello.x
