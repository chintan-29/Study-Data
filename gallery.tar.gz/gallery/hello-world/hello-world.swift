import io;
  
printf("Hello world!");
